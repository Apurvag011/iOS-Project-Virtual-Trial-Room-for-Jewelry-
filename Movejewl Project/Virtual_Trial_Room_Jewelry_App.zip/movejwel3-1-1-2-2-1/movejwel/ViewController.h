//
//  ViewController.h
//  movejwel
//
//  Created by Niket Kapadia on 07/01/13.
//  Copyright (c) 2013 __MyCompanyName__. All rights reserved.
//
#import "colorpicker.h"
#import <UIKit/UIKit.h>
#import <QuartzCore/Quartzcore.h>
#import <MobileCoreServices/MobileCoreServices.h>
#import <AssetsLibrary/AssetsLibrary.h>
#import "InfColorPicker.h"
#import "ARFontPickerViewController1.h"

@interface ViewController : UIViewController<UIGestureRecognizerDelegate,UIAlertViewDelegate,UIImagePickerControllerDelegate,UINavigationControllerDelegate,UIPopoverControllerDelegate,InfColorPickerControllerDelegate>{
    CGPoint start1;
    CGPoint start2;
    CGPoint start3;
    CGPoint start4;
    CGPoint start5;
    CGPoint currentPoint;
    UITextField *alt;
    UIPopoverController *popoverController;
    UIPopoverController *popoverController1;
    BOOL newMedia;
    
    UIPopoverController* activePopover;
	BOOL updateLive;
}
@property CGPoint start5;
@property CGPoint start4;
@property CGPoint start3;
@property CGPoint start2;
@property CGPoint start1;
@property (retain, nonatomic) IBOutlet UIImageView *backImage;
@property UITextField *alt;
@property (strong, nonatomic) IBOutlet UIScrollView *nscroll;
-(NSMutableArray*) myStaticArray;
@property (strong, nonatomic) IBOutlet UIScrollView *escroll;
@property (retain, nonatomic) IBOutlet UIButton *setimage;
@property(retain,atomic) ALAssetsLibrary *library;
@property (strong, nonatomic) IBOutlet UIImageView *n1image;
@property (nonatomic, retain) UIPopoverController *popoverController;
@property (strong, nonatomic) IBOutlet UIImageView *n2image;
@property (retain, nonatomic) IBOutlet UIView *ParentView;
@property (nonatomic, retain) UIPopoverController *popoverController1;
@property (strong, nonatomic) IBOutlet UIImageView *e1image;

@property (strong, nonatomic) IBOutlet UIImageView *e2image;
@property (strong, nonatomic) IBOutlet UIView *blackview;
@property (retain, nonatomic) IBOutlet UIButton *saveButton;

@property (strong, nonatomic) IBOutlet UISegmentedControl *seg;

- (IBAction)segchange:(id)sender;
- (IBAction)displayText:(id)sender;
@property (strong, nonatomic) IBOutlet UILabel *myText;
//- (IBAction)font1:(id)sender;
@property (strong, nonatomic) IBOutlet UIButton *saveSupport;
- (IBAction)saveSupportAction:(id)sender;
- (IBAction)choosePhoto:(id)sender;
- (IBAction)chooseEarring:(id)sender;
- (IBAction)setimage:(id)sender;
- (IBAction)selectFromGallery:(id)sender;
//- (IBAction)color1:(id)sender;
-(IBAction)handleSingleTap3:(id)sender;
//-(IBAction)longpress1:(UILongPressGestureRecognizer *)gestureRecognizer;

@property (retain, nonatomic) IBOutlet UILabel *myt1;


@property (retain, nonatomic) IBOutlet UILabel *myt2;


@property (retain, nonatomic) IBOutlet UILabel *myt3;

- (IBAction)TrashIconShow:(id)sender;

@property (retain, nonatomic) IBOutlet UIImageView *trashimage;
@property (retain, nonatomic) IBOutlet UILabel *lb1;
@property (retain, nonatomic) IBOutlet UILabel *lb2;

@end



















