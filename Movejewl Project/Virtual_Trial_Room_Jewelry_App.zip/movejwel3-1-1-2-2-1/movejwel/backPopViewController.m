//
//  backPopViewController.m
//  movejwel
//
//  Created by Niket Kapadia on 15/01/13.
//  Copyright (c) 2013 __MyCompanyName__. All rights reserved.
//

#import "backPopViewController.h"
#import "ViewController.h"
@interface backPopViewController ()

@end

@implementation backPopViewController
@synthesize backGroundScroll;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    //////-------------------------------------------------------------
    
    
    int numberOfImages = 3;
    CGFloat currentx = 0.0f;
    
    for (int i=1; i <= numberOfImages; i++) {
        
        // create image
        NSString *imageName = [NSString stringWithFormat:@"f%d.jpg", i];
        UIImage *image = [UIImage imageNamed:imageName];
        UIImageView *imageView = [[UIImageView alloc] initWithImage:image];
        UITapGestureRecognizer *tapGestureRecognize = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(singleTapGestureRecognizer:)];
        tapGestureRecognize.delegate = self;
        tapGestureRecognize.numberOfTapsRequired = 1;
        imageView.userInteractionEnabled = YES;
        [imageView addGestureRecognizer:tapGestureRecognize];     
        
        // put image on correct position
        CGRect rect = imageView.frame;
        rect.origin.x = currentx;
        rect.size.height =400;
        rect.size.width = 400;
        imageView.frame = rect;
        imageView.tag =i;            // update currentX
        currentx += rect.size.width;
        
        //[scrollView addSubview:imageView];
        
        [backGroundScroll addSubview:imageView];  
        
        ///////.........................
        
        
        
    }
    backGroundScroll.contentSize = CGSizeMake(currentx, 400);    
    [backGroundScroll setScrollEnabled:YES];
    [backGroundScroll setPagingEnabled:YES];
    
    backGroundScroll.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleRightMargin;
    [self.view addSubview:backGroundScroll];
    
    
    //////-------------------------------------------------------------
    [super viewDidLoad];
	// Do any additional setup after loading the view.
}
- (void)singleTapGestureRecognizer:(UITapGestureRecognizer *)gestureRecognizer
{
    UIImageView *tappedImageView = (UIImageView *)[gestureRecognizer view];
    UIImageView *imageView = [[UIImageView alloc] initWithImage:tappedImageView.image];
    ViewController *vc = [[ViewController alloc] init];
    imageView.frame = vc.blackview.frame;
    [vc.blackview addSubview:imageView];
    vc.n1image.hidden = YES;
    [self.navigationController pushViewController:vc animated:YES];
}

- (void)someMethod:(UIViewController*)sender
{
    
}
- (void)viewDidUnload
{
    [self setBackGroundScroll:nil];
    [super viewDidUnload];
    // Release any retained subviews of the main view.
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
	return YES;
}

- (void)dealloc {
    [backGroundScroll release];
    [super dealloc];
}
@end
