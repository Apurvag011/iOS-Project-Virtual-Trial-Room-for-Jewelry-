//
//  event.h
//  movejwel
//
//  Created by Niket Kapadia on 09/01/13.
//  Copyright (c) 2013 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface event : NSManagedObject

@end
