//
//  ViewController.m
//  movejwel
//
//  Created by Niket Kapadia on 07/01/13.
//  Copyright (c) 2013 __MyCompanyName__. All rights reserved.
//
#import "myal.h"
#import "ViewController.h"
#import <MobileCoreServices/MobileCoreServices.h>


@interface ViewController ()

@end

@implementation ViewController
@synthesize lb1;
@synthesize lb2;
@synthesize myt1;
@synthesize myt2;
@synthesize myt3;
@synthesize nscroll;
@synthesize escroll;
@synthesize setimage;
@synthesize trashimage;
@synthesize n1image;
@synthesize n2image;
@synthesize library;
@synthesize e1image;
@synthesize e2image;
@synthesize ParentView;
@synthesize blackview;
@synthesize saveButton;
@synthesize seg;
@synthesize start1;
@synthesize start2;
@synthesize start3;
@synthesize start4;
@synthesize start5;
@synthesize backImage;
static int seg1;
@synthesize alt;
@synthesize myText;
@synthesize saveSupport;
@synthesize popoverController;
@synthesize popoverController1;
static int pic,cam=0;
static float curx;
static float cury;
static int myalerttext=0;
static int myalertsave=0;
static int trashtag=0;
static int my1=0,my2=0,my3=0;
-(NSMutableArray*) myStaticArray
{
    static NSMutableArray* theArray = nil;
    if (theArray == nil)
    {
        theArray = [[NSMutableArray alloc] init];
    }
    return theArray;
}
- (void)someMethod:(UIViewController*)sender
{

}

- (IBAction)setimage:(id)sender {
    
    
    if ([UIImagePickerController isSourceTypeAvailable:
         UIImagePickerControllerSourceTypeCamera])
    {
        UIImagePickerController *imagePicker =
        [[UIImagePickerController alloc] init];
        imagePicker.delegate = self;
        imagePicker.sourceType = 
        UIImagePickerControllerSourceTypeCamera;
        imagePicker.mediaTypes = [NSArray arrayWithObjects:
                                  (NSString *) kUTTypeImage,
                                  nil];
        imagePicker.allowsEditing = NO;
        [self presentModalViewController:imagePicker 
                                animated:YES];
        [imagePicker release];
        newMedia = YES;
        cam=1;
    }

}

- (IBAction)selectFromGallery:(id)sender {
    
    if ([UIImagePickerController isSourceTypeAvailable:
         UIImagePickerControllerSourceTypeSavedPhotosAlbum])
    {
        UIImagePickerController *imagePicker =
        [[UIImagePickerController alloc] init];
        imagePicker.delegate = self;
        imagePicker.sourceType = 
        UIImagePickerControllerSourceTypePhotoLibrary;
        imagePicker.mediaTypes = [NSArray arrayWithObjects:
                                  (NSString *) kUTTypeImage,
                                  nil];
        imagePicker.allowsEditing = NO;
        //[self presentViewController:imagePicker animated:YES completion:nil];
        UIPopoverController *popover = [[UIPopoverController alloc] initWithContentViewController:imagePicker];
        [popover setPopoverContentSize:CGSizeMake(320,320)];
        [popover presentPopoverFromRect:CGRectMake(30,800,300,200) inView:self.view permittedArrowDirections:UIPopoverArrowDirectionDown animated:YES];
        self.popoverController = popover;        
        newMedia = NO;
        cam=1;
}

}


//////// color
//////////////////////////////////////
//////////////////////////////////

- (void) applyPickedColor: (InfColorPickerController*) picker
{   
   
    if(1==my1)
    {
        myt1.textColor =picker.resultColor;
    }
    else if (1==my2) {
        myt2.textColor = picker.resultColor;
    }
    else if (1==my3) {
        myt3.textColor = picker.resultColor;
    }
    else {
        myText.textColor = picker.resultColor;
    }
    
}





- (void) popoverControllerDidDismissPopover: (UIPopoverController*) popoverController
{
	if( [ popoverController.contentViewController isKindOfClass: [ InfColorPickerController class ] ] ) {
		InfColorPickerController* picker = (InfColorPickerController*) popoverController.contentViewController;
		[ self applyPickedColor: picker ];
	}
	
	if(popoverController == activePopover ) {
		activePopover = nil;
	}
}

- (void)showPopover: (UIPopoverController*)popover from:(id) sender
{
	popover.delegate = self;
    
    UIView *v= (UIView *)[sender view];
    if(v==myt1)
    {
        my1=1;
        my2=0;
        my3=0;
    }
    else if (v==myt2)
    {
        my2 =1;
        my1=0;
        my3=0;
    }
    else if (v==myt3)
    {
        my3 =1;
        my1=0;
        my2=0;
    }
    else {
        my1 = 0;
        my2 = 0;
        my3 = 0;
    }
	activePopover = [ popover retain ];
	
	if( [sender isKindOfClass: [ UIBarButtonItem class ] ] ) {
		[ activePopover presentPopoverFromBarButtonItem: sender
							   permittedArrowDirections: UIPopoverArrowDirectionAny
											   animated: YES ];
	}
	else {
		//UIView *senderView = sender;
        UIView *sendrvw = (UIView *)[sender view];
		
		[activePopover presentPopoverFromRect:[sendrvw bounds] 
										inView: sendrvw 
					  permittedArrowDirections: UIPopoverArrowDirectionAny 
									  animated: YES ];
	}
}

//------------------------------------------------------------------------------

- (BOOL) dismissActivePopover
{
	if( activePopover ) {
		[ activePopover dismissPopoverAnimated: YES ];
		[ self popoverControllerDidDismissPopover: activePopover ];
		
		return YES;
	}
	
	return NO;
}



- (void) colorPickerControllerDidChangeColor: (InfColorPickerController*) picker
{
	if(!updateLive ){
		[ self applyPickedColor: picker ];
    }
}



- (void) colorPickerControllerDidFinish: (InfColorPickerController*) picker
{
	[ self applyPickedColor: picker ];
    
	[ activePopover dismissPopoverAnimated: YES ];
}



- (IBAction) takeUpdateLive: (UISwitch*) sender
{   	updateLive = [ sender isOn ];
}

//-----------------------------------------------



/*- (IBAction)color1:(id)sender 
{
        
    
    
    
    
    
    if( [self dismissActivePopover ] )
		return;
	
	InfColorPickerController* picker = [ InfColorPickerController colorPickerViewController ];
	
	picker.sourceColor = self.view.backgroundColor;
	picker.delegate = self;
	
	UIPopoverController *popover =  [[UIPopoverController alloc ] initWithContentViewController: picker ];
    
	[self showPopover:popover from :sender]; 
    //[self showPopover:popoverController from:sender];
    
   
    
}*/

-(IBAction)handleSingleTap:(id)sender
{


    
    if( [self dismissActivePopover ] )
		return;
	
	InfColorPickerController* picker = [ InfColorPickerController colorPickerViewController ];
	
	picker.sourceColor = self.view.backgroundColor;
	picker.delegate = self;
	
	UIPopoverController *popover =  [[UIPopoverController alloc ] initWithContentViewController: picker ];

	[self showPopover:popover from :sender]; 
    //[self showPopover:popoverController from:sender];

}

















//////////////////////
////////////////////////////color/////////////////////

/*- (IBAction)font1:(id)sender 
{
    ARFontPickerViewController1 *controller = [[ARFontPickerViewController1 alloc] initWithStyle:UITableViewStylePlain];
     controller.delegate = self;
    [self presentModalViewController:controller animated:YES];
	[controller release];
    my1= 0;
    my2= 0;
    my3 = 0;
}
*/
/*- (void)fontPickerViewController:(ARFontPickerViewController1 *)fontPicker didSelectFont:(NSString *)fontName 
{
	//self.myText.text =fontName; 
    
	myText.font = [UIFont fontWithName:fontName size:50];
    
	[fontPicker dismissModalViewControllerAnimated:YES];
}*/





-(IBAction)handleSingleTap1:(id)sender
{
    ARFontPickerViewController1 *controller = [[ARFontPickerViewController1 alloc] initWithStyle:UITableViewStylePlain];
    controller.delegate = self;
    [self presentModalViewController:controller animated:YES];
	[controller release];
}

- (void)fontPickerViewController:(ARFontPickerViewController1 *)fontPicker didSelectFont:(NSString *)fontName 
{
	//self.myText.text =fontName; 
    if(1==my1)
    {
        myt1.font = [UIFont fontWithName:fontName size:50];
    }
    else if (1==my2) {
        myt2.font = [UIFont fontWithName:fontName size:50];
    }
    else if (1==my3) {
        myt3.font = [UIFont fontWithName:fontName size:50];
    }
    else {
        myText.font = [UIFont fontWithName:fontName size:50];
    }
	[fontPicker dismissModalViewControllerAnimated:YES];
}




-(IBAction)handleSingleTap3:(id)sender
{
    ARFontPickerViewController1 *controller = [[ARFontPickerViewController1 alloc] initWithStyle:UITableViewStylePlain];
    controller.delegate = self;
    [self presentModalViewController:controller animated:YES];
   	[controller release];
    UIView *v= (UIView *)[sender view];
    if(v==myt1)
    {
        my1=1;
        my2=0;
        my3=0;
    }
    else if (v==myt2)
    {
        my2 =1;
        my1=0;
        my3=0;
    }
    else if (v==myt3)
    {
        my3 =1;
        my1=0;
        my2=0;
    }
    
}



/*-(void)fontPickerViewController:(ARFontPickerViewController1 *)fontPicker didSelectFont:(NSString *)fontName:(id)sender
{
	//self.myText.text =fontName;
       //myText.font = [UIFont fontWithName:fontName size:50];
    UILabel *l = (UILabel *)[sender view];
    l.font = [UIFont fontWithName:fontName size:50];
	[fontPicker dismissModalViewControllerAnimated:YES];
}*/




















-(void)image:(UIImage *)image
finishedSavingWithError:(NSError *)error 
 contextInfo:(void *)contextInfo
{
    if (error) {
        UIAlertView *alert = [[UIAlertView alloc]
                              initWithTitle: @"Save failed"
                              message: @"Failed to save image"\
                              delegate: nil
                              cancelButtonTitle:@"OK"
                              otherButtonTitles:nil];
        [alert show];
        [alert release];
    }
}

- (IBAction)choosePhoto:(id)sender
{
	
	// Show an image picker to allow the user to choose a new photo.
	UIImagePickerController *imagePickerController = [[UIImagePickerController alloc] init];
    imagePickerController.delegate = self;
    imagePickerController.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
    UIPopoverController *popover = [[UIPopoverController alloc] initWithContentViewController:imagePickerController];
    [popover setPopoverContentSize:CGSizeMake(320,320)];
    [popover presentPopoverFromRect:CGRectMake(nscroll.center.x-150,nscroll.center.y-100,300,200) inView:self.view permittedArrowDirections:UIPopoverArrowDirectionLeft animated:YES];
    self.popoverController = popover;
    pic=1;
}

- (IBAction)chooseEarring:(id)sender {
    UIImagePickerController *imagePickerController = [[UIImagePickerController alloc] init];
    imagePickerController.delegate = self;
    imagePickerController.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
    UIPopoverController *popover = [[UIPopoverController alloc] initWithContentViewController:imagePickerController];
    [popover setPopoverContentSize:CGSizeMake(320,320)];
    [popover presentPopoverFromRect:CGRectMake(escroll.center.x,escroll.center.y-150, 300, 200) inView:self.view permittedArrowDirections:UIPopoverArrowDirectionDown animated:YES];
    self.popoverController = popover;
    pic=2;

}


- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingImage:(UIImage *)selectedImage editingInfo:(NSDictionary *)editingInfo {
    
 if (pic==1){
        cury = nscroll.contentSize.height+10;
	UIImageView *img = [[UIImageView alloc] initWithFrame:CGRectMake(0, cury, 230, 230 )];
    img.image = selectedImage;
    UITapGestureRecognizer *tapGestureRecognize = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(singleTapGestureRecognizer:)];
    tapGestureRecognize.delegate = self;
    tapGestureRecognize.numberOfTapsRequired = 1;
    img.userInteractionEnabled = YES;
    [img addGestureRecognizer:tapGestureRecognize];    
        [nscroll addSubview:img];
        nscroll.contentSize = CGSizeMake(800, cury+230);
       
    }
    if(pic==2){
    curx = escroll.contentSize.width+10;
        UIImageView *img = [[UIImageView alloc] initWithFrame:CGRectMake( curx,0, 230, 230 )];
        img.image = selectedImage;
        UITapGestureRecognizer *tapGestureRecognize = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(singleTapGestureRecognizer:)];
        tapGestureRecognize.delegate = self;
        tapGestureRecognize.numberOfTapsRequired = 1;
        img.userInteractionEnabled = YES;
        [img addGestureRecognizer:tapGestureRecognize];    
        
        [escroll addSubview:img]; 
        escroll.contentSize = CGSizeMake(curx+230, 800);
        
    }
  
    if(cam==1){
        backImage.image = selectedImage;
        backImage.hidden = backImage.hidden = NO;
     
        cam=0;
        //[self dismissModalViewControllerAnimated:YES];
                 
    }
    //---------------
    [picker dismissModalViewControllerAnimated:YES];
}


- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker {
	// The user canceled -- simply dismiss the image picker.
	[self dismissModalViewControllerAnimated:YES];
}

- (void)rotationDetected1:(UIRotationGestureRecognizer *)gestureRecognizer
{

    [self adjustAnchorPointForGestureRecognizer1:gestureRecognizer];
    if ([gestureRecognizer state] == UIGestureRecognizerStateBegan || [gestureRecognizer state] == UIGestureRecognizerStateChanged)
    {
        CGFloat angle = gestureRecognizer.rotation;
        myText.transform = CGAffineTransformRotate(myText.transform, angle);  
        gestureRecognizer.rotation = 0.0;     
    }
}
- (void)rotationDetected:(UIRotationGestureRecognizer *)gestureRecognizer
{
    [self adjustAnchorPointForGestureRecognizer:gestureRecognizer];
    if ([gestureRecognizer state] == UIGestureRecognizerStateBegan || [gestureRecognizer state] == UIGestureRecognizerStateChanged)
    {
        UIImageView *tappedImageView = (UIImageView *)[gestureRecognizer view];
        CGFloat angle = gestureRecognizer.rotation;
        tappedImageView.transform = CGAffineTransformRotate(tappedImageView.transform, angle);
        gestureRecognizer.rotation = 0.0;
    }
}
- (void)rotationDetected2:(UIRotationGestureRecognizer *)gestureRecognizer
{
    
    [self adjustAnchorPointForGestureRecognizer2:gestureRecognizer];
    if ([gestureRecognizer state] == UIGestureRecognizerStateBegan || [gestureRecognizer state] == UIGestureRecognizerStateChanged)
    {
        UILabel *l = (UILabel *)[gestureRecognizer view];
        CGFloat angle = gestureRecognizer.rotation;
        l.transform = CGAffineTransformRotate(l.transform, angle);  
        gestureRecognizer.rotation = 0.0;     
    }
}

-(void)longpress1 :(UILongPressGestureRecognizer *)gestureRecognizer{
    
    [self adjustAnchorPointForGestureRecognizer:gestureRecognizer];
    if ([gestureRecognizer state] == UIGestureRecognizerStateBegan || [gestureRecognizer state] == UIGestureRecognizerStateChanged)
    {
       
        UIImageView *tappedImageView = (UIImageView *)[gestureRecognizer view];
        //tappedImageView.hidden = tappedImageView.hidden = YES;
       
        //tappedImageView.image = [UIImage imageNamed:NULL]; 
       // tappedImageView.image = NULL;
        //tappedImageView.image = NULL;
        
        
        
    
    
        
             
        
        
        
        
        
        
        nscroll = [[UIScrollView alloc] initWithFrame:nscroll.frame];
        
        int numberOfImages = 5;
        CGFloat currenty = 0.0f;
        CGFloat currenty1 = tappedImageView.frame.origin.y;  
        for (int i=1; i <= numberOfImages; i++) {
            
            // create image
            NSString *imageName = [NSString stringWithFormat:@"n%d.png", i];
            UIImage *image = [UIImage imageNamed:imageName];

            if(tappedImageView.image == image)
            {
        
                tappedImageView.image = NULL;   
            
            }
            else if (tappedImageView.image == NULL) {
                
            
                
            
            UIImageView *imageView = [[UIImageView alloc] initWithImage:image];
            

            UILongPressGestureRecognizer *longp = [[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(longpress1:)];
            [imageView addGestureRecognizer:longp];
            [longp setDelegate:self];
                
                UITapGestureRecognizer *tapGestureRecognize = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(singleTapGestureRecognizere:)];
                tapGestureRecognize.delegate = self;
                tapGestureRecognize.numberOfTapsRequired = 1;
                imageView.userInteractionEnabled = YES;
                [imageView addGestureRecognizer:tapGestureRecognize];
                imageView.userInteractionEnabled = YES;
                

                
         /*   CGRect rect = tappedImageView.frame;
            rect.origin.y = currenty1;
            rect.size.height =200;
            //rect.size.width = 150;
            imageView.frame = rect;
            //imageView.frame = CGRectMake(frameX, frameY, frameW, frameH);
            imageView.tag =i;            // update currentX
            currenty1 += rect.size.height;*/
                
                CGRect rect = imageView.frame;
                rect.origin.y = currenty1;
                rect.size.height =200;
                rect.size.width = 150;
                imageView.frame = rect;
                imageView.tag =i;            
                currenty1 += rect.size.height; 
                
                
            
            [nscroll addSubview:imageView];
            }
            
            else 
            
            
            
            {
                
                UIImageView *imageView = [[UIImageView alloc] initWithImage:image];
                
                
                UILongPressGestureRecognizer *longp = [[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(longpress1:)];
                [imageView addGestureRecognizer:longp];
                [longp setDelegate:self];
                
                UITapGestureRecognizer *tapGestureRecognize = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(singleTapGestureRecognizere:)];
                tapGestureRecognize.delegate = self;
                tapGestureRecognize.numberOfTapsRequired = 1;
                imageView.userInteractionEnabled = YES;
                [imageView addGestureRecognizer:tapGestureRecognize];
                imageView.userInteractionEnabled = YES;
                
                CGRect rect = imageView.frame;
                rect.origin.y = currenty;
                rect.size.height =200;
                rect.size.width = 150;
                imageView.frame = rect;
                imageView.tag =i;            
                currenty += rect.size.height;  
                
                [nscroll addSubview:imageView];
            }
        
            
        }
        
        nscroll.contentSize = CGSizeMake(150, currenty+currenty1);
        [nscroll setScrollEnabled:YES];
        [nscroll setPagingEnabled:YES];
        nscroll.frame = CGRectMake(ParentView.frame.origin.x, ParentView.frame.origin.y, 150, 489);
        nscroll.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleRightMargin;
        [nscroll setBackgroundColor:[UIColor grayColor]];
        [self.view addSubview:nscroll];
        
    }
        
        
}












-(void)longpress2 :(UILongPressGestureRecognizer *)gestureRecognizer{
    
    [self adjustAnchorPointForGestureRecognizer1:gestureRecognizer];
    if ([gestureRecognizer state] == UIGestureRecognizerStateBegan || [gestureRecognizer state] == UIGestureRecognizerStateChanged) {
        
        myText.text = NULL;
                
    }
}

-(void)longpress3 :(UILongPressGestureRecognizer *)gestureRecognizer{
    
    [self adjustAnchorPointForGestureRecognizer2:gestureRecognizer];
    if ([gestureRecognizer state] == UIGestureRecognizerStateBegan || [gestureRecognizer state] == UIGestureRecognizerStateChanged) {
       
        UIView *v = (UIView *)[gestureRecognizer view];
        if(v==myt1)
        {
            myt1.text =NULL;
            my1 = 0 ;
        }
        else if (v==myt2) {
            myt2.text = NULL;
            my2 =0 ;
        }
        else if (v==myt3) {
            myt3.text = NULL;
            my3=0;
        }
        
    }
}




- (void)pinchDetected2:(UIPinchGestureRecognizer *)gestureRecognizer{ 
    [self adjustAnchorPointForGestureRecognizer2:gestureRecognizer];
    if ([gestureRecognizer state] == UIGestureRecognizerStateBegan || [gestureRecognizer state] == UIGestureRecognizerStateChanged)
    { 
        UILabel *l = (UILabel *)[gestureRecognizer view];
        CGFloat scale = gestureRecognizer.scale;
        gestureRecognizer.scale = 1.0;
        if ((l.frame.size.width > 0) && (l.frame.size.height > 0) && (l.frame.size.width < 1000) && (l.frame.size.height < 1500))
        {
            l.transform =CGAffineTransformScale(l.transform, scale,scale);
        }
        else
        {
            l.transform =CGAffineTransformScale(l.transform, 0.99, 0.99);    
        }
    }
}









- (void)pinchDetected1:(UIPinchGestureRecognizer *)gestureRecognizer{ 
  [self adjustAnchorPointForGestureRecognizer1:gestureRecognizer];
    if ([gestureRecognizer state] == UIGestureRecognizerStateBegan || [gestureRecognizer state] == UIGestureRecognizerStateChanged)
    {
        CGFloat scale = gestureRecognizer.scale;
        gestureRecognizer.scale = 1.0;
        if ((myText.frame.size.width > 0) && (myText.frame.size.height > 0) && (myText.frame.size.width < 1000) && (myText.frame.size.height < 1500))
        {
            myText.transform =CGAffineTransformScale(myText.transform, scale,scale);
        }
        else
        {
            myText.transform =CGAffineTransformScale(myText.transform, 0.99, 0.99);    
        }
    }
}
-(void)pinchDetected:(UIPinchGestureRecognizer *)gestureRecognizer{
    
    [self adjustAnchorPointForGestureRecognizer:gestureRecognizer];
    
    if ([gestureRecognizer state] == UIGestureRecognizerStateBegan || [gestureRecognizer state] == UIGestureRecognizerStateChanged)
    {
        UIImageView *tappedImageView = (UIImageView *)[gestureRecognizer view];
        CGFloat scale = gestureRecognizer.scale;
        gestureRecognizer.scale = 1.0;
        
        if ((tappedImageView.frame.size.width > 1) && (tappedImageView.frame.size.height > 1) && (tappedImageView.frame.size.width < blackview.frame.size.width) && (tappedImageView.frame.size.height < blackview.frame.size.height))
        {
            
            tappedImageView.transform =CGAffineTransformScale(tappedImageView.transform, scale,scale);
       
        }else
        {
            tappedImageView.transform =CGAffineTransformScale(tappedImageView.transform, 0.99, 0.99);    
        }
        
    }    
}
- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldRecognizeSimultaneouslyWithGestureRecognizer:(UIGestureRecognizer *)otherGestureRecognizer {
    // if the gesture recognizers are on different views, don't allow simultaneous recognition
    if (gestureRecognizer.view != otherGestureRecognizer.view)
        return NO;
    
    // if either of the gesture recognizers is the long press, don't allow simultaneous recognition
    //if ([gestureRecognizer isKindOfClass:[UILongPressGestureRecognizer class]] || [otherGestureRecognizer isKindOfClass:[UILongPressGestureRecognizer class]])
      //  return NO;
    
    return YES;
}

- (void)adjustAnchorPointForGestureRecognizer2:(UIGestureRecognizer *)gestureRecognizer {
    if (gestureRecognizer.state == UIGestureRecognizerStateBegan)
    {
        UILabel *l = (UILabel *)[gestureRecognizer view];
        
        CGPoint locationInView1 = [gestureRecognizer locationInView:l];
        CGPoint locationInSuperview1 = [gestureRecognizer locationInView:l.superview];
        
        l.layer.anchorPoint = CGPointMake(locationInView1.x / myText.bounds.size.width, locationInView1.y / myText.bounds.size.height);
        l.center = locationInSuperview1;
    }
}




- (void)adjustAnchorPointForGestureRecognizer1:(UIGestureRecognizer *)gestureRecognizer {
    if (gestureRecognizer.state == UIGestureRecognizerStateBegan)
    {
        
    CGPoint locationInView1 = [gestureRecognizer locationInView:myText];
    CGPoint locationInSuperview1 = [gestureRecognizer locationInView:myText.superview];
    
    myText.layer.anchorPoint = CGPointMake(locationInView1.x / myText.bounds.size.width, locationInView1.y / myText.bounds.size.height);
    myText.center = locationInSuperview1;
    }
}
- (void)adjustAnchorPointForGestureRecognizer:(UIGestureRecognizer *)gestureRecognizer {
    if (gestureRecognizer.state == UIGestureRecognizerStateBegan) {
        //UIView *piece = gestureRecognizer.view;
        CGPoint locationInView = [gestureRecognizer locationInView:n1image];
        CGPoint locationInSuperview = [gestureRecognizer locationInView:n1image.superview];
        
        n1image.layer.anchorPoint = CGPointMake(locationInView.x / n1image.bounds.size.width, locationInView.y / n1image.bounds.size.height);
        n1image.center = locationInSuperview;
    }
}

/*- (void)singleTapGestureRecognizer1:(UITapGestureRecognizer *)gestureRecognizer
{
    UIRotationGestureRecognizer *rotationRecognizer = [[UIRotationGestureRecognizer alloc] initWithTarget:self action:@selector(rotationDetected1:)];
    [myText addGestureRecognizer:rotationRecognizer];
    [rotationRecognizer setDelegate:self];    
    
    UIPinchGestureRecognizer *pinchRecognizer = [[UIPinchGestureRecognizer alloc] initWithTarget:self action:@selector(pinchDetected1:)];
    [myText addGestureRecognizer:pinchRecognizer];
    [pinchRecognizer setDelegate:self];
    
    UILongPressGestureRecognizer *longp1 = [[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(longpress2:)];
    [myText addGestureRecognizer:longp1];
    [longp1 setDelegate:self];
    
    
}*/
-(void)singleTapGestureRecognizer:(UITapGestureRecognizer *)gestureRecognizer
{
    
    
    UIImageView *tappedImageView = (UIImageView *)[gestureRecognizer view];
    if(seg1 == 0)
    {
        n1image.image = tappedImageView.image;
        n1image.hidden = n1image.hidden =NO;
        
        UIRotationGestureRecognizer *rotationRecognizer = [[UIRotationGestureRecognizer alloc] initWithTarget:self action:@selector(rotationDetected:)];
        [n1image addGestureRecognizer:rotationRecognizer];
        [rotationRecognizer setDelegate:self];
        
        
        UIPinchGestureRecognizer *pinchRecognizer = [[UIPinchGestureRecognizer alloc] initWithTarget:self action:@selector(pinchDetected:)];
        [n1image addGestureRecognizer:pinchRecognizer];
        [pinchRecognizer setDelegate:self];
        
        UILongPressGestureRecognizer *longp = [[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(longpress1:)];
        [n1image addGestureRecognizer:longp];
        [longp setDelegate:self];
        
               
        
        
        
        
        
        
    }
    else if (n2image.image==NULL && seg1==1) {
        n2image.image = tappedImageView.image;
        n2image.hidden = n2image.hidden =NO;
        
        
        
        UIRotationGestureRecognizer *rotationRecognizer = [[UIRotationGestureRecognizer alloc] initWithTarget:self action:@selector(rotationDetected:)];
        [n2image addGestureRecognizer:rotationRecognizer];
        [rotationRecognizer setDelegate:self];
        
        UIPinchGestureRecognizer *pinchRecognizer = [[UIPinchGestureRecognizer alloc] initWithTarget:self action:@selector(pinchDetected:)];
        
        [n2image addGestureRecognizer:pinchRecognizer];
        [pinchRecognizer setDelegate:self];
        
        
        UILongPressGestureRecognizer *longp = [[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(longpress1:)];
        [n2image addGestureRecognizer:longp];
        [longp setDelegate:self];        
    }
    else if (n2image.image !=NULL && seg1 == 1)
    {
        CGRect r = CGRectMake(blackview.frame.origin.x+100, blackview.frame.origin.y+200, 200, 100);
        UIImageView *img = [[UIImageView alloc] initWithFrame:r];
        img.image = tappedImageView.image;
        img.userInteractionEnabled = YES;
        UIRotationGestureRecognizer *rotationRecognizer = [[UIRotationGestureRecognizer alloc] initWithTarget:self action:@selector(rotationDetected:)];
        [img addGestureRecognizer:rotationRecognizer];
        
        UIPinchGestureRecognizer *pinchRecognizer = [[UIPinchGestureRecognizer alloc] initWithTarget:self action:@selector(pinchDetected:)];
        [img addGestureRecognizer:pinchRecognizer];
        [pinchRecognizer setDelegate:self];
        
        UILongPressGestureRecognizer *longp = [[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(longpress1:)];
        [img addGestureRecognizer:longp];
        [longp setDelegate:self];        
        
        [blackview addSubview:img];
        
        
    }  
}


- (void)singleTapGestureRecognizere:(UITapGestureRecognizer *)gestureRecognizer
{
    UIImageView *tappedImageView = (UIImageView *)[gestureRecognizer view];
    if(seg1 == 0)
    {
        e1image.image = tappedImageView.image;
        e1image.hidden = e1image.hidden =NO;
        UIRotationGestureRecognizer *rotationRecognizer = [[UIRotationGestureRecognizer alloc] initWithTarget:self action:@selector(rotationDetected:)];
        [e1image addGestureRecognizer:rotationRecognizer];
        [rotationRecognizer setDelegate:self];
        
        
        UIPinchGestureRecognizer *pinchRecognizer = [[UIPinchGestureRecognizer alloc] initWithTarget:self action:@selector(pinchDetected:)];
        [e1image addGestureRecognizer:pinchRecognizer];
        [pinchRecognizer setDelegate:self];
        
        
        UILongPressGestureRecognizer *longp = [[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(longpress1:)];
        [e1image addGestureRecognizer:longp];
        [longp setDelegate:self];

        
        
        
        

    }
    else if (seg1==1 && e2image.image == NULL) {
        e2image.image = tappedImageView.image;
        e2image.hidden = e2image.hidden =NO;
        UIRotationGestureRecognizer *rotationRecognizer = [[UIRotationGestureRecognizer alloc] initWithTarget:self action:@selector(rotationDetected:)];
        [e2image addGestureRecognizer:rotationRecognizer];
        [rotationRecognizer setDelegate:self];
        
        UIPinchGestureRecognizer *pinchRecognizer = [[UIPinchGestureRecognizer alloc] initWithTarget:self action:@selector(pinchDetected:)];
        [e2image addGestureRecognizer:pinchRecognizer];
        [pinchRecognizer setDelegate:self];
        
        UILongPressGestureRecognizer *longp = [[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(longpress1:)];
        [e2image addGestureRecognizer:longp];
        [longp setDelegate:self];
        
    }
    else if (e2image.image !=NULL && seg1 == 1)
    {
        CGRect r = CGRectMake(blackview.frame.origin.x+100, blackview.frame.origin.y+100, 200, 100);
        UIImageView *img = [[UIImageView alloc] initWithFrame:r];
        img.image = tappedImageView.image;
        img.userInteractionEnabled = YES;
        UIRotationGestureRecognizer *rotationRecognizer = [[UIRotationGestureRecognizer alloc] initWithTarget:self action:@selector(rotationDetected:)];
        [img addGestureRecognizer:rotationRecognizer];
        [rotationRecognizer setDelegate:self];
        
        UIPinchGestureRecognizer *pinchRecognizer = [[UIPinchGestureRecognizer alloc] initWithTarget:self action:@selector(pinchDetected:)];
        [img addGestureRecognizer:pinchRecognizer];
        [pinchRecognizer setDelegate:self];
        UILongPressGestureRecognizer *longp = [[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(longpress1:)];
        [img addGestureRecognizer:longp];
        [longp setDelegate:self];
        
        
        
        [blackview addSubview:img];
        
        
    }
    
}
- (void)viewDidLoad
{
 [super viewDidLoad];
    
    /////
  
    n1image.hidden = n1image.hidden =YES;
    n2image.hidden= n2image.hidden= YES;
    n1image.hidden = n1image.hidden =YES;
    n2image.hidden= n2image.hidden= YES;
     [[self myStaticArray] addObject: @"My Catalogue"];    
    
    myText.text = NULL;  
    
    myt1.text = NULL;
    myt2.text = NULL;
    myt3.text = NULL;
    
    
    
    
    
    
    
    
    
    ////
    ////////for neckless..................
        nscroll = [[UIScrollView alloc] initWithFrame:nscroll.frame];
        
        int numberOfImages = 5;
        CGFloat currenty = 0.0f;
        
        for (int i=1; i <= numberOfImages; i++) {
            
            // create image
            NSString *imageName = [NSString stringWithFormat:@"n%d.png", i];
            UIImage *image = [UIImage imageNamed:imageName];
            UIImageView *imageView = [[UIImageView alloc] initWithImage:image];
            UITapGestureRecognizer *tapGestureRecognize = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(singleTapGestureRecognizer:)];
            tapGestureRecognize.delegate = self;
            tapGestureRecognize.numberOfTapsRequired = 1;
            imageView.userInteractionEnabled = YES;
            [imageView addGestureRecognizer:tapGestureRecognize]; 
            
            UILongPressGestureRecognizer *longp1 = [[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(longpress1:)];
            [imageView addGestureRecognizer:longp1];
            [longp1 setDelegate:self];
            //longp1.delegate = self;
            
                     
            
            
            // put image on correct position
            CGRect rect = imageView.frame;
            rect.origin.y = currenty;
            rect.size.height =200;
            rect.size.width = 150;
            imageView.frame = rect;
             imageView.tag =i;            // update currentX
            currenty += rect.size.height;
            
            //[scrollView addSubview:imageView];
            
            
            
            
            
            UIControl *mask = [[UIControl alloc] initWithFrame:imageView.frame];
            
            // add the image as a subview of this mask
            CGRect imageSize = imageView.frame;
            imageView.frame = CGRectMake(ParentView.frame.origin.x, ParentView.frame.origin.y, imageSize.size.width,imageSize.size.height);
            [mask addSubview:imageView];
            imageView.userInteractionEnabled = YES;
            // add a target-action for the desired control events to this mask
            [mask addTarget:self action:@selector(someMethod:) forControlEvents:UIControlEventTouchUpInside];
        
            // add the mask as a subview instead of the image
            [nscroll addSubview:mask];
       ///////.........................
            
         
            
        }
    nscroll.contentSize = CGSizeMake(150, currenty);
    [nscroll setScrollEnabled:YES];
    [nscroll setPagingEnabled:YES];
    nscroll.frame = CGRectMake(ParentView.frame.origin.x, ParentView.frame.origin.y, 150, 489);
    nscroll.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleRightMargin;
    [nscroll setBackgroundColor:[UIColor grayColor]];
    [self.view addSubview:nscroll];
        
    
    
   //............................
    
        
    
    
    
    
    
    
    
    
    
    
    // [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    
    //for earrings......    
    
    
    escroll = [[UIScrollView alloc] initWithFrame:escroll.frame];
    
     numberOfImages = 5;
     int currentX = 0.0f;
    
    for (int i=1; i <= numberOfImages; i++) {
        
        // create image
        NSString *imageName = [NSString stringWithFormat:@"e%d.png", i];
        UIImage *image = [UIImage imageNamed:imageName];
        UIImageView *imageView = [[UIImageView alloc] initWithImage:image];
        UITapGestureRecognizer *tapGestureRecognize = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(singleTapGestureRecognizere:)];
        tapGestureRecognize.delegate = self;
        tapGestureRecognize.numberOfTapsRequired = 1;
        imageView.userInteractionEnabled = YES;
        [imageView addGestureRecognizer:tapGestureRecognize];
        imageView.userInteractionEnabled = YES;
        
        
        
        UILongPressGestureRecognizer *longp1 = [[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(longpress1:)];
        [imageView addGestureRecognizer:longp1];
        [longp1 setDelegate:self];
       // longp1.delegate = self;
        
        
        
        
        
        
        
        // put image on correct position
        CGRect rect = imageView.frame;
        rect.origin.x = currentX;
        rect.size.height =200;
        rect.size.width = 200;
        imageView.frame = rect;
        imageView.userInteractionEnabled = YES;
       
        // update currentX
        currentX += rect.size.width;
        
        //[scrollView addSubview:imageView];
        
        
        
        
        
        UIControl *mask = [[UIControl alloc] initWithFrame:imageView.frame];
        
        // add the image as a subview of this mask
        CGRect imageSize = imageView.frame;
        imageView.frame = CGRectMake(0, 0, imageSize.size.width,imageSize.size.height);
        [mask addSubview:imageView];
        
        // add a target-action for the desired control events to this mask
        [mask addTarget:self action:@selector(someMethod:) forControlEvents:UIControlEventTouchUpInside];
        
        // add the mask as a subview instead of the image
        [escroll addSubview:mask];  
        
        ///////.........................
        
        
        
    }
    escroll.contentSize = CGSizeMake(currenty, 200);
    [escroll setScrollEnabled:YES];
    [escroll setPagingEnabled:YES];
    escroll.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleRightMargin;
    escroll.frame = CGRectMake(nscroll.frame.size.width,ParentView.frame.size.height-230 ,ParentView.frame.size.width - nscroll.frame.size.width , 230);
    [escroll setBackgroundColor:[UIColor grayColor]];
    [self.view addSubview:escroll];
  //  [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.    
    
    //..............................................
    blackview.frame = CGRectMake(nscroll.frame.size.width, ParentView.frame.origin.y, ParentView.frame.size.width - nscroll.frame.size.width, ParentView.frame.size.height - escroll.frame.size.height);
    //seg.frame = CGRectMake(nscroll.frame.size.width, 20, 200, 50);
    self.library = [[ALAssetsLibrary alloc]init];
    lb1.hidden = YES;
    lb2.hidden = YES;
     
}

- (void)viewDidUnload
{
    
    [self setNscroll:nil];
    [self setEscroll:nil];
    [self setN1image:nil];
    [self setN2image:nil];
    [self setE1image:nil];
    [self setE2image:nil];
    [self setBlackview:nil];
    [self setSeg:nil];
    
    [self setMyText:nil];
    [self setSaveSupport:nil];
    [self setBackImage:nil];
    [self setParentView:nil];
    [self setSaveButton:nil];
    [self setMyt1:nil];
    [self setMyt2:nil];
    [self setMyt3:nil];
    [self setTrashimage:nil];
    [self setLb1:nil];
    [self setLb2:nil];
    [super viewDidUnload];
    // Release any retained subviews of the main view.
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)orientation
{   return NO;
    //return  (orientation == UIInterfaceOrientationLandscapeRight);
}


-(BOOL)shouldAutorotate{
    UIInterfaceOrientation orientation = [[UIDevice currentDevice] orientation];
            
        
        
        
    if(orientation == UIInterfaceOrientationLandscapeLeft)
    {
        seg.center = CGPointMake(100, 100);
      //  ParentView.frame = CGRectMake(0, 0, 1024, 768);       
        blackview.frame = CGRectMake(nscroll.frame.size.width, 300,100,100);
        self.escroll.center = CGPointMake(100,100);
    }
    else
    {
        blackview.frame = CGRectMake(nscroll.frame.size.width, ParentView.frame.origin.y, ParentView.frame.size.width - nscroll.frame.size.width, ParentView.frame.size.height - escroll.frame.size.height);
        escroll.frame = CGRectMake(nscroll.frame.size.width,ParentView.frame.size.height-230 ,ParentView.frame.size.width - nscroll.frame.size.width , 230);    }
    return NO;
}
float startX = 0;
float startY = 0;

- (void) touchesBegan:(NSSet*)touches withEvent:(UIEvent*)event
{
    UITouch * touch = (UITouch *)[touches anyObject];    // When a touch starts, get the current location in the view
    UIView *v= [touch view];
    currentPoint = [[touches anyObject] locationInView:v];
}
- (void)touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event
{
    UITouch * touch = (UITouch *)[touches anyObject];    // When a touch starts, get the current location in the view
    UIView *v= [touch view];
    if(v!=blackview && v!=backImage){
    CGPoint activePoint = [[touches anyObject] locationInView:v];
    
    // Determine new point based on where the touch is now located
    CGPoint newPoint = CGPointMake(v.center.x + (activePoint.x - currentPoint.x),
                                   v.center.y + (activePoint.y - currentPoint.y));
    
    //--------------------------------------------------------
    // Make sure we stay within the bounds of the parent view
    //--------------------------------------------------------
    float midPointX = CGRectGetMidX(v.bounds);
    // If too far right...
    if (newPoint.x > v.superview.bounds.size.width  - midPointX)
        newPoint.x = v.superview.bounds.size.width - midPointX;
    else if (newPoint.x < midPointX)  // If too far left...
        newPoint.x = midPointX;
    
    float midPointY = CGRectGetMidY(v.bounds);
    // If too far down...
    if (newPoint.y > v.superview.bounds.size.height  - midPointY)
        newPoint.y = v.superview.bounds.size.height - midPointY;
    else if (newPoint.y < midPointY)  // If too far up...
        newPoint.y = midPointY;
    
        lb1.text = [NSString stringWithFormat:@"x=%f,y=%f",newPoint.x,newPoint.y];
        lb2.text = [NSString stringWithFormat:@"o=(%f,%f) and s=(%f,%f)",trashimage.frame.origin.x,trashimage.frame.origin.y
                    ,trashimage.frame.size.width,trashimage.frame.size.height];
        if(newPoint.x<trashimage.frame.size.width+trashimage.frame.origin.x && newPoint.x>trashimage.frame.origin.x && newPoint.y<trashimage.frame.origin.y+trashimage.frame.size.height && newPoint.y>trashimage.frame.origin.y && trashtag==1){
            v.hidden = v.hidden = YES;
        }
        else{
            // Set new center location
            v.center = newPoint;
            }
    }
}




- (void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event {}
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (myalerttext==1)
        
    {
        if (buttonIndex == 0 && myText.text == NULL)
        {
                myText.text = alt.text;
                myText.hidden = myText.hidden = NO;
            myText.userInteractionEnabled = YES;
            UIRotationGestureRecognizer *rotationRecognizer = [[UIRotationGestureRecognizer alloc] initWithTarget:self action:@selector(rotationDetected1:)];
            [myText addGestureRecognizer:rotationRecognizer];
            [rotationRecognizer setDelegate:self];    
            
            UIPinchGestureRecognizer *pinchRecognizer = [[UIPinchGestureRecognizer alloc] initWithTarget:self action:@selector(pinchDetected1:)];
            [myText addGestureRecognizer:pinchRecognizer];
            [pinchRecognizer setDelegate:self];
            
            UILongPressGestureRecognizer *longp1 = [[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(longpress2:)];
            [myText addGestureRecognizer:longp1];
            [longp1 setDelegate:self];        
            
            
            UITapGestureRecognizer *singleFingerTap = 
            [[UITapGestureRecognizer alloc] initWithTarget:self 
                                                    action:@selector(handleSingleTap:)];
            singleFingerTap.numberOfTapsRequired = 2;
            //myText.userInteractionEnabled = YES;

            
            [myText addGestureRecognizer:singleFingerTap];
            [singleFingerTap setDelegate:self];
            
            
            UITapGestureRecognizer *singleFingerTap1 = 
            [[UITapGestureRecognizer alloc] initWithTarget:self 
                                                    action:@selector(handleSingleTap1:)];
            singleFingerTap1.numberOfTapsRequired = 2;
            [myText addGestureRecognizer:singleFingerTap1];
            [singleFingerTap1 setDelegate:self];


            
                
        }
        else if (buttonIndex ==0 && myText.text != NULL)
        {
            
           /* UILabel *u = [[UILabel alloc] initWithFrame:CGRectMake(100, 200, 300, 100)];
            u.userInteractionEnabled = YES;
            u.text = alt.text;
            //u.shadowColor = [UIColor redColor];
           // u.text = [UItex fontWithName:alt.text size:50]; 
            [u setFont:[UIFont systemFontOfSize:40]];
            u.textColor = [UIColor blueColor];
            u.textAlignment = UITextAlignmentCenter;
            u.backgroundColor = [UIColor clearColor];
            //u.backgroundColor = [UIColor viewFlipsideBackgroundColor];
            [blackview addSubview:u];
            
           // u.hidden = u.hidden = NO;
            UIRotationGestureRecognizer *rotationRecognizer = [[UIRotationGestureRecognizer alloc] initWithTarget:self action:@selector(rotationDetected2:)];
            [u addGestureRecognizer:rotationRecognizer];
            [rotationRecognizer setDelegate:self];    
            
            UIPinchGestureRecognizer *pinchRecognizer = [[UIPinchGestureRecognizer alloc] initWithTarget:self action:@selector(pinchDetected2:)];
            [u addGestureRecognizer:pinchRecognizer];
            [pinchRecognizer setDelegate:self];
            
            UILongPressGestureRecognizer *longp1 = [[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(longpress3:)];
            [u addGestureRecognizer:longp1];
            [longp1 setDelegate:self];
            
            
            UITapGestureRecognizer *singleFingerTap3 = 
            [[UITapGestureRecognizer alloc] initWithTarget:self 
                                                    action:@selector(handleSingleTap3:)];
            singleFingerTap3.numberOfTapsRequired = 2;
            //myText.userInteractionEnabled = YES;
            
            
            [u addGestureRecognizer:singleFingerTap3];
            [singleFingerTap3 setDelegate:self];
            
            
           UITapGestureRecognizer *singleFingerTap = 
            [[UITapGestureRecognizer alloc] initWithTarget:self 
                                                    action:@selector(handleSingleTap:)];
            singleFingerTap.numberOfTapsRequired = 2;
            [u addGestureRecognizer:singleFingerTap];
            [singleFingerTap setDelegate:self];
            */

        
            
            
    if(myt1.text==NULL )
        {
            myt1.hidden = myt1.hidden = NO;
            myt1.text = alt.text;
            UIRotationGestureRecognizer *rotationRecognizer = [[UIRotationGestureRecognizer alloc] initWithTarget:self action:@selector(rotationDetected2:)];
            [myt1 addGestureRecognizer:rotationRecognizer];
            [rotationRecognizer setDelegate:self];    
            
            UIPinchGestureRecognizer *pinchRecognizer = [[UIPinchGestureRecognizer alloc] initWithTarget:self action:@selector(pinchDetected2:)];
            [myt1 addGestureRecognizer:pinchRecognizer];
            [pinchRecognizer setDelegate:self];
            
            UILongPressGestureRecognizer *longp1 = [[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(longpress3:)];
            [myt1 addGestureRecognizer:longp1];
            [longp1 setDelegate:self];
            
            
            UITapGestureRecognizer *singleFingerTap3 = 
            [[UITapGestureRecognizer alloc] initWithTarget:self 
                                                    action:@selector(handleSingleTap3:)];
            singleFingerTap3.numberOfTapsRequired = 2;
            //myText.userInteractionEnabled = YES;
            
            
            [myt1 addGestureRecognizer:singleFingerTap3];
            [singleFingerTap3 setDelegate:self];
            
            
            UITapGestureRecognizer *singleFingerTap = 
            [[UITapGestureRecognizer alloc] initWithTarget:self 
                                                    action:@selector(handleSingleTap:)];
            singleFingerTap.numberOfTapsRequired = 2;
            [myt1 addGestureRecognizer:singleFingerTap];
            [singleFingerTap setDelegate:self]; 

        }
    else if (myt1.text !=NULL && myt2.text == NULL) {
        myt2.hidden = myt2.hidden = NO;    
        myt2.text = alt.text;

        UIRotationGestureRecognizer *rotationRecognizer = [[UIRotationGestureRecognizer alloc] initWithTarget:self action:@selector(rotationDetected2:)];
        [myt2 addGestureRecognizer:rotationRecognizer];
        [rotationRecognizer setDelegate:self];    
        
        UIPinchGestureRecognizer *pinchRecognizer = [[UIPinchGestureRecognizer alloc] initWithTarget:self action:@selector(pinchDetected2:)];
        [myt2 addGestureRecognizer:pinchRecognizer];
        [pinchRecognizer setDelegate:self];
        
        UILongPressGestureRecognizer *longp1 = [[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(longpress3:)];
        [myt2 addGestureRecognizer:longp1];
        [longp1 setDelegate:self];
        
        
        UITapGestureRecognizer *singleFingerTap3 = 
        [[UITapGestureRecognizer alloc] initWithTarget:self 
                                                action:@selector(handleSingleTap3:)];
        singleFingerTap3.numberOfTapsRequired = 2;
        //myText.userInteractionEnabled = YES;
        
        
        [myt2 addGestureRecognizer:singleFingerTap3];
        [singleFingerTap3 setDelegate:self];
        
        
        UITapGestureRecognizer *singleFingerTap = 
        [[UITapGestureRecognizer alloc] initWithTarget:self 
                                                action:@selector(handleSingleTap:)];
        singleFingerTap.numberOfTapsRequired = 2;
        [myt2 addGestureRecognizer:singleFingerTap];
        [singleFingerTap setDelegate:self];
        }
    else if (myt2.text !=NULL && myt1.text != NULL && myt3.text == NULL) {
        myt3.hidden = myt3.hidden = NO;    
        myt3.text = alt.text;
        UIRotationGestureRecognizer *rotationRecognizer = [[UIRotationGestureRecognizer alloc] initWithTarget:self action:@selector(rotationDetected2:)];
        [myt3 addGestureRecognizer:rotationRecognizer];
        [rotationRecognizer setDelegate:self];    
        
        UIPinchGestureRecognizer *pinchRecognizer = [[UIPinchGestureRecognizer alloc] initWithTarget:self action:@selector(pinchDetected2:)];
        [myt3 addGestureRecognizer:pinchRecognizer];
        [pinchRecognizer setDelegate:self];
        
        UILongPressGestureRecognizer *longp1 = [[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(longpress3:)];
        [myt3 addGestureRecognizer:longp1];
        [longp1 setDelegate:self];
        
        
        UITapGestureRecognizer *singleFingerTap3 = 
        [[UITapGestureRecognizer alloc] initWithTarget:self 
                                                action:@selector(handleSingleTap3:)];
        singleFingerTap3.numberOfTapsRequired = 2;
        //myText.userInteractionEnabled = YES;
        
        
        [myt3 addGestureRecognizer:singleFingerTap3];
        [singleFingerTap3 setDelegate:self];
        
        
        UITapGestureRecognizer *singleFingerTap = 
        [[UITapGestureRecognizer alloc] initWithTarget:self 
                                                action:@selector(handleSingleTap:)];
        singleFingerTap.numberOfTapsRequired = 2;
        [myt3 addGestureRecognizer:singleFingerTap];
        [singleFingerTap setDelegate:self];
    }
            
}        
        
        
        else if(buttonIndex == 1)
        {
            // No
        }
        
        
        myalerttext=0;
        
    }
    if(myalertsave==1)
    {
        if (buttonIndex == 0)
        {
            UIGraphicsBeginImageContext(blackview.bounds.size);
            NSString *foodTitle = alt.text;
            [blackview.layer renderInContext:UIGraphicsGetCurrentContext()];
            
            UIImage *viewImage = UIGraphicsGetImageFromCurrentImageContext();
            
            UIGraphicsEndImageContext();
            
            //    UIImageWriteToMyCataLogueAlbum(viewImage, nil, nil, nil);
            [self.library
             saveImage:viewImage
             toAlbum:foodTitle
             withCompletionBlock:^(NSError *error) {
                 if (error!=nil) {
                     NSLog(@"Big error: %@", [error description]);
                 }
             }];
            
            [[self myStaticArray] addObject:alt.text];
        }
        else if (buttonIndex == 1)
        {
            // No
        }
        
        
        myalertsave =0;
        [popoverController dismissPopoverAnimated:YES];
    }
}

- (IBAction)segchange:(id)sender {
    if([seg selectedSegmentIndex] == 0)
    {
        seg1 = 0;
        n2image.hidden = n2image.hidden = YES;
        e2image.hidden = e2image.hidden = YES;
        NSArray *viewsToRemove = [blackview subviews];
        for (UIView *v in viewsToRemove) {
            if(v== n1image || v== n2image || v== e1image || v==e2image || v== myText ||v== myt1 ||v==myt2 ||v==myt3||v==blackview||v==backImage)
            {
                
            }
            else{
                [v removeFromSuperview];
            }
        }        
    }
    else if ([seg selectedSegmentIndex]==1) {
        n2image.hidden = n2image.hidden = NO;
        e2image.hidden = e2image.hidden = NO;
        seg1 = 1;
    }
    
    
}

- (IBAction)displayText:(id)sender {
    UIAlertView *alert = [[UIAlertView alloc] init];
    [alert setTitle:@"Enter the Text"];
    [alert setMessage:@"Ok to Show the Text or Cancel"];
    [alert setDelegate:self];
    [alert setCancelButtonIndex:2];
    [alert addButtonWithTitle:@"Yes"];
    [alert addButtonWithTitle:@"Cancel"];
   alt= [[UITextField alloc] initWithFrame:CGRectMake(12.0, 45.0, 260.0, 35.0)];
    alt.borderStyle = UITextBorderStyleRoundedRect;
    [alt setBackgroundColor:[UIColor whiteColor]];
    [alert addSubview:alt];
    [alert show];
    myalerttext=1; 
}
- (IBAction)saveSupportAction:(id)sender {
    UIViewController *popsave = [[UIViewController alloc] init];
    UIPopoverController *popover = [[UIPopoverController alloc] initWithContentViewController:popsave];
    popover.delegate = self;
    popover.popoverContentSize = CGSizeMake(320, 497);
    [popover presentPopoverFromRect:saveButton.frame inView:self.view permittedArrowDirections:UIPopoverArrowDirectionAny animated:YES];
    
    int y1=10;
    //int count1 = [albums count];
    //albums = [NSArray arrayWithObjects:@"My Catalogue", nil];
    NSEnumerator *e = [[self myStaticArray] objectEnumerator];
    id object;
    int i=0;
    while (object = [e nextObject]) {
        // do something with object
        NSString *foodTitle = [[self myStaticArray] objectAtIndex:i];
        CGRect buttonFrame = CGRectMake( 10, y1, 320, 100 );
        UIButton *button = [[UIButton alloc] initWithFrame:buttonFrame];
        button.backgroundColor = [UIColor blackColor];
        [button setTitle:foodTitle forState: UIControlStateNormal];
        [button addTarget:self action:@selector(btnSelected:) forControlEvents:UIControlEventTouchUpInside];
        [button setTag:i];
        [button setTitleColor: [UIColor blueColor] forState: UIControlStateNormal];
        [popsave.view addSubview:button];
        y1 = y1+110;
        i++;
        
    }
    CGRect buttonFrame = CGRectMake( 10, y1, 320, 100 );
    UIButton *button = [[UIButton alloc] initWithFrame:buttonFrame];
    button.backgroundColor = [UIColor blackColor];
    [button setTitle:@"Add New Album" forState: UIControlStateNormal];
    [button addTarget:self action:@selector(newSelected:) forControlEvents:UIControlEventTouchUpInside];
    [button setTitleColor: [UIColor blueColor] forState: UIControlStateNormal];
    [popsave.view addSubview:button];
    self.popoverController = popover;
}
- (void) btnSelected:(UIButton *)paramSender{
    
    UIGraphicsBeginImageContext(blackview.bounds.size);
    NSString *foodTitle = [[self myStaticArray] objectAtIndex:paramSender.tag];
    [blackview.layer renderInContext:UIGraphicsGetCurrentContext()];
    
    UIImage *viewImage = UIGraphicsGetImageFromCurrentImageContext();
    
    UIGraphicsEndImageContext();
    
    //    UIImageWriteToMyCataLogueAlbum(viewImage, nil, nil, nil);
    [self.library
     saveImage:viewImage
     toAlbum:foodTitle
     withCompletionBlock:^(NSError *error) {
         if (error!=nil) {
             NSLog(@"Big error: %@", [error description]);
         }
     }];
    [popoverController dismissPopoverAnimated:YES];
}
- (void) newSelected:(UIButton *)paramSender{
    UIAlertView *alert = [[UIAlertView alloc] init];
    [alert setTitle:@"Enter the Album Name"];
    [alert setMessage:@"Yes to Save and Create or Cancel"];
    [alert setDelegate:self];
    [alert setCancelButtonIndex:2];
    [alert addButtonWithTitle:@"Yes"];
    [alert addButtonWithTitle:@"Cancel"];
    alt= [[UITextField alloc] initWithFrame:CGRectMake(12.0, 45.0, 260.0, 25.0)];
    [alt setBackgroundColor:[UIColor whiteColor]];
    [alert addSubview:alt];
    [alert show];
    myalertsave =1;
    
    
}    



     - (void)dealloc {
         [setimage release];
         [backImage release];
         [ParentView release];
         [saveButton release];
         [myt1 release];
         [myt2 release];
         [myt3 release];
         [trashimage release];
         [lb1 release];
         [lb2 release];
         [super dealloc];
     }






- (IBAction)TrashIconShow:(id)sender {
    
    if (trashtag==0) {
    trashimage.frame = CGRectMake(blackview.frame.size.width-200, blackview.frame.size.height-200, 90, 90);
    trashimage.hidden = trashimage.hidden = NO;
    trashtag =1;
    [blackview addSubview:trashimage];
    }
    else if (trashtag==1)
    {
        trashimage.hidden=trashimage.hidden= YES;
        trashtag=0;
    }
}
@end
