//
//  AppDelegate.h
//  movejwel
//
//  Created by Niket Kapadia on 07/01/13.
//  Copyright (c) 2013 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ViewController.h"

@interface AppDelegate : UIResponder <UIApplicationDelegate>{
    
    ViewController *vc;
    
   



}
@property (nonatomic, retain) IBOutlet ViewController *vc;

@property (nonatomic, retain) IBOutlet UIWindow *window;
@end
