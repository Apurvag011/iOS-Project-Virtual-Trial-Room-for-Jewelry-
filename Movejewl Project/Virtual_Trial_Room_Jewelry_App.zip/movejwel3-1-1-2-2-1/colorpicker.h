//
//  colorpicker.h
//  movejwel
//
//  Created by Niket Kapadia on 18/01/13.
//  Copyright (c) 2013 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface colorpicker : NSObject<UIApplicationDelegate>
@end
